Lovely 2D Cat

14x Cat

Animations Included:
Idle
Move

6x Char

Animations Included:
Idle
Move
Die

11x Boss

Animations Included:
Idle
Action
Die

2x Etc

Animations Included:
Action


Current version 1.0

------------------------------------------------------------------------------------------








